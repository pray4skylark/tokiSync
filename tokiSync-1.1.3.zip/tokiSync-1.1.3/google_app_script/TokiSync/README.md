이스크립트를 사용하기 전 프로젝트 설정(Project Settings) -> 스크립트 속성에서 입력하세요.
1. ROOT_FOLDER_ID: 만화가 저장될 구글 드라이브 폴더 ID
2. SECRET_KEY: Tampermonkey와 공유할 비밀번호

